DEBUG = True

SECRET_KEY = 'django-insecure-!a(&#da18sz0opz0)+9f@9kl1qf1ked=*%*p9l6v+rkfju$qt0'